"""
Inference script for SpanBERTForMarkerExtraction model.
Generates submission.jsonl for the SemEval PsyCoMark task.
"""

import json
import sys
import torch
import numpy as np
from typing import List, Tuple, Dict, Any
from transformers import AutoTokenizer
from tqdm import tqdm

# Import the model class
from span_model_v3 import SpanBERTForMarkerExtraction


# Configuration - UPDATE THESE PATHS AS NEEDED
MODEL_PATH = "spanbert_trained/best_model.pt"  # Path to your trained model weights
TEST_FILE = "dev_rehydrated.jsonl"
SUBMISSION_FILE = "submission.jsonl"
PRETRAINED_MODEL_NAME = "SpanBERT/spanbert-base-cased"
MAX_SPAN_LENGTH = 5
THRESHOLD = 0.5
BATCH_SIZE = 16
MAX_LENGTH = 128
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Marker types in order (must match training)
MARKER_TYPES = ["Actor", "Action", "Effect", "Evidence", "Victim"]


def load_data(file_path: str) -> List[Dict[str, Any]]:
    """Load test data from JSONL file."""
    data = []
    with open(file_path, 'r') as f:
        for i, line in enumerate(f):
            try:
                item = json.loads(line.strip())
                item["_id"] = item.get("_id", f"sample_{i}")
                item["text"] = item.get("text", "")
                item["conspiracy"] = item.get("conspiracy", "No")
                data.append(item)
            except json.JSONDecodeError:
                print(f"Skipping invalid JSON line at index {i}: {line.strip()}")
    print(f"Loaded {len(data)} samples for inference.")
    return data


def enumerate_spans(sequence_length: int, max_span_length: int) -> List[Tuple[int, int]]:
    """Enumerate all valid spans up to max_span_length."""
    spans = []
    for start_idx in range(sequence_length):
        for end_idx in range(start_idx, min(start_idx + max_span_length, sequence_length)):
            spans.append((start_idx, end_idx))
    return spans


def token_spans_to_char_spans(
    token_spans: List[Tuple[int, int, str]],  # (start_token, end_token, marker_type)
    offset_mapping: List[Tuple[int, int]],
    text: str
) -> List[Dict[str, Any]]:
    """
    Convert token-level spans to character-level spans.
    
    Args:
        token_spans: List of (start_token_idx, end_token_idx, marker_type) - end is inclusive
        offset_mapping: List of (char_start, char_end) for each token
        text: Original text
        
    Returns:
        List of marker dictionaries with startIndex, endIndex, type, text
    """
    markers = []
    
    for start_tok, end_tok, marker_type in token_spans:
        # Get character offsets
        # start_tok and end_tok are inclusive token indices
        
        # Skip if indices are out of bounds
        if start_tok >= len(offset_mapping) or end_tok >= len(offset_mapping):
            continue
            
        start_offset = offset_mapping[start_tok]
        end_offset = offset_mapping[end_tok]
        
        # Skip special tokens (offset is (0, 0) for [CLS], [SEP], [PAD])
        if start_offset is None or end_offset is None:
            continue
        if start_offset[0] == 0 and start_offset[1] == 0:
            continue
        if end_offset[0] == 0 and end_offset[1] == 0:
            continue
            
        char_start = start_offset[0]
        char_end = end_offset[1]
        
        # Extract span text
        span_text = text[char_start:char_end]
        
        markers.append({
            "startIndex": char_start,
            "endIndex": char_end,
            "type": marker_type,
            "text": span_text
        })
    
    return markers


def run_inference(
    model: SpanBERTForMarkerExtraction,
    tokenizer: AutoTokenizer,
    data: List[Dict[str, Any]],
    batch_size: int = 16,
    threshold: float = 0.5
) -> List[List[Dict[str, Any]]]:
    """
    Run inference on all samples and return predicted markers.
    
    Returns:
        List of marker lists, one per sample
    """
    model.eval()
    all_predictions = []
    
    with torch.no_grad():
        for i in tqdm(range(0, len(data), batch_size), desc="Running inference"):
            batch_data = data[i:i + batch_size]
            texts = [d["text"] for d in batch_data]
            
            # Tokenize
            encoded = tokenizer(
                texts,
                truncation=True,
                padding="max_length",
                max_length=MAX_LENGTH,
                return_tensors="pt",
                return_offsets_mapping=True
            )
            
            input_ids = encoded["input_ids"].to(DEVICE)
            attention_mask = encoded["attention_mask"].to(DEVICE)
            offset_mappings = encoded["offset_mapping"].tolist()
            
            # Get actual sequence lengths (excluding padding)
            seq_lengths = attention_mask.sum(dim=1).tolist()
            
            # For each sample in batch, we need to process individually
            # because span enumeration depends on sequence length
            for j in range(len(batch_data)):
                sample_input_ids = input_ids[j:j+1]
                sample_attention_mask = attention_mask[j:j+1]
                sample_offset_mapping = offset_mappings[j]
                sample_text = texts[j]
                seq_len = int(seq_lengths[j])
                
                # Enumerate spans for this sequence
                spans = enumerate_spans(seq_len, MAX_SPAN_LENGTH)
                
                if not spans:
                    all_predictions.append([])
                    continue
                
                # Forward pass
                outputs = model(
                    input_ids=sample_input_ids,
                    attention_mask=sample_attention_mask,
                    spans=spans
                )
                
                logits = outputs["logits"]  # [1, num_spans, num_labels]
                probs = torch.sigmoid(logits).squeeze(0)  # [num_spans, num_labels]
                
                # Get predictions above threshold
                predicted_token_spans = []
                
                for span_idx, (start_tok, end_tok) in enumerate(spans):
                    span_probs = probs[span_idx]  # [num_labels]
                    
                    for label_idx, prob in enumerate(span_probs):
                        if prob.item() >= threshold:
                            marker_type = MARKER_TYPES[label_idx]
                            predicted_token_spans.append((start_tok, end_tok, marker_type))
                
                # Convert token spans to character spans
                char_markers = token_spans_to_char_spans(
                    predicted_token_spans,
                    sample_offset_mapping,
                    sample_text
                )
                
                all_predictions.append(char_markers)
    
    return all_predictions


def main():
    print(f"Device: {DEVICE}")
    print(f"Loading model from: {MODEL_PATH}")
    
    # Load tokenizer
    print("Loading tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(PRETRAINED_MODEL_NAME)
    
    # Load model
    print("Loading model...")
    model = SpanBERTForMarkerExtraction(
        pretrained_model_name=PRETRAINED_MODEL_NAME,
        max_span_length=MAX_SPAN_LENGTH,
        num_labels=len(MARKER_TYPES)
    )
    
    # Load trained weights
    print(f"Loading weights from: {MODEL_PATH}")
    checkpoint = torch.load(MODEL_PATH, map_location=DEVICE)
    
    # Handle different checkpoint formats
    if isinstance(checkpoint, dict) and "model_state_dict" in checkpoint:
        model.load_state_dict(checkpoint["model_state_dict"])
        print("  Loaded from 'model_state_dict' key")
    elif isinstance(checkpoint, dict) and "state_dict" in checkpoint:
        model.load_state_dict(checkpoint["state_dict"])
        print("  Loaded from 'state_dict' key")
    elif isinstance(checkpoint, dict) and not any(k.startswith("bert.") or k.startswith("classifier.") for k in checkpoint.keys()):
        # Checkpoint is a dict but keys don't look like model weights - try common keys
        for key in ["model", "net", "network"]:
            if key in checkpoint:
                model.load_state_dict(checkpoint[key])
                print(f"  Loaded from '{key}' key")
                break
        else:
            print("  Warning: Couldn't find model weights in checkpoint dict. Keys found:", list(checkpoint.keys())[:5])
            sys.exit(1)
    else:
        # Assume it's directly the state dict
        model.load_state_dict(checkpoint)
        print("  Loaded state dict directly")
    
    model.to(DEVICE)
    print("Model loaded successfully!")
    
    # Load test data
    print(f"\nLoading test data from: {TEST_FILE}")
    test_data = load_data(TEST_FILE)
    
    if not test_data:
        print("Error: No data loaded!")
        sys.exit(1)
    
    # Run inference
    print(f"\nRunning inference with threshold={THRESHOLD}...")
    predictions = run_inference(
        model=model,
        tokenizer=tokenizer,
        data=test_data,
        batch_size=BATCH_SIZE,
        threshold=THRESHOLD
    )
    
    # Create submission file
    print(f"\nGenerating submission file: {SUBMISSION_FILE}")
    
    with open(SUBMISSION_FILE, 'w') as f:
        for i, sample in enumerate(test_data):
            submission_obj = {
                "_id": sample["_id"],
                "conspiracy": sample["conspiracy"],
                "markers": predictions[i]
            }
            f.write(json.dumps(submission_obj) + "\n")
    
    # Print summary statistics
    total_markers = sum(len(p) for p in predictions)
    samples_with_markers = sum(1 for p in predictions if p)
    
    print(f"\n{'='*50}")
    print("Inference Complete!")
    print(f"{'='*50}")
    print(f"Total samples: {len(test_data)}")
    print(f"Samples with predictions: {samples_with_markers}")
    print(f"Total markers predicted: {total_markers}")
    print(f"Average markers per sample: {total_markers/len(test_data):.2f}")
    
    # Count by marker type
    type_counts = {mt: 0 for mt in MARKER_TYPES}
    for pred_list in predictions:
        for marker in pred_list:
            type_counts[marker["type"]] += 1
    
    print(f"\nMarkers by type:")
    for mt, count in type_counts.items():
        print(f"  {mt}: {count}")
    
    print(f"\nSubmission saved to: {SUBMISSION_FILE}")


if __name__ == "__main__":
    main()
