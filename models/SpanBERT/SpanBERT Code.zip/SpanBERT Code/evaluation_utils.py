"""
Evaluation utilities for SpanBERT Marker Extraction model.

This module provides functions to:
1. Compute accuracy, precision, recall, F1 for each marker type → save to CSV
2. Generate confusion matrices for each marker type → save to CSV
3. Save validation predictions with true values in JSONL format (similar to input data)
"""

import torch
import pandas as pd
import json
from typing import List, Dict, Tuple, Optional
from tqdm import tqdm
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix


# Marker types in order (must match SimpleSpanDataset)
MARKER_TYPES = ["Actor", "Action", "Effect", "Evidence", "Victim"]
MARKER_TO_IDX = {m: i for i, m in enumerate(MARKER_TYPES)}


def evaluate_model(
    model,
    dataloader,
    device,
    threshold: float = 0.5
) -> Tuple[Dict, List[Dict]]:
    """
    Run evaluation on the validation set and collect all predictions.
    
    Args:
        model: SpanBERTForMarkerExtraction model
        dataloader: Validation DataLoader
        device: torch device (cuda/cpu)
        threshold: Threshold for converting logits to binary predictions
        
    Returns:
        all_predictions: Dict with keys for each marker type containing y_true and y_pred lists
        sample_predictions: List of dicts with per-sample predictions for detailed output
    """
    model.eval()
    
    # Storage for per-marker-type metrics
    all_predictions = {marker: {'y_true': [], 'y_pred': []} for marker in MARKER_TYPES}
    
    # Storage for per-sample detailed predictions
    sample_predictions = []
    
    with torch.no_grad():
        pbar = tqdm(dataloader, desc="Evaluating")
        
        for batch in pbar:
            for sample in batch:
                input_ids = sample['input_ids'].unsqueeze(0).to(device)
                attention_mask = sample['attention_mask'].unsqueeze(0).to(device)
                labels = sample['labels'].unsqueeze(0).to(device)  # [1, num_spans, 5]
                spans = sample['spans']
                sample_id = sample['_id']
                text = sample['text']
                
                # Forward pass
                outputs = model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    spans=spans,
                    labels=labels
                )
                
                logits = outputs['logits']  # [1, num_spans, 5]
                
                # Convert logits to probabilities and then to binary predictions
                probs = torch.sigmoid(logits)
                preds = (probs > threshold).float()
                
                # Squeeze batch dimension
                labels_np = labels.squeeze(0).cpu().numpy()  # [num_spans, 5]
                preds_np = preds.squeeze(0).cpu().numpy()    # [num_spans, 5]
                probs_np = probs.squeeze(0).cpu().numpy()    # [num_spans, 5]
                
                # Collect predictions for each marker type (for aggregate metrics)
                for marker_idx, marker_name in enumerate(MARKER_TYPES):
                    all_predictions[marker_name]['y_true'].extend(labels_np[:, marker_idx].tolist())
                    all_predictions[marker_name]['y_pred'].extend(preds_np[:, marker_idx].tolist())
                
                # Collect per-sample predictions for detailed output
                # Get offset mapping to convert token spans back to character spans
                # We need to retrieve this from the original dataset sample
                sample_pred_info = {
                    '_id': sample_id,
                    'text': text,
                    'spans': spans,
                    'labels': labels_np,
                    'predictions': preds_np,
                    'probabilities': probs_np,
                    'input_ids': sample['input_ids'].numpy()
                }
                sample_predictions.append(sample_pred_info)
    
    return all_predictions, sample_predictions


def compute_metrics_per_marker(all_predictions: Dict) -> pd.DataFrame:
    """
    Compute accuracy, precision, recall, F1 for each marker type.
    
    Args:
        all_predictions: Dict from evaluate_model()
        
    Returns:
        DataFrame with metrics for each marker type
    """
    metrics_data = []
    
    for marker_name in MARKER_TYPES:
        y_true = all_predictions[marker_name]['y_true']
        y_pred = all_predictions[marker_name]['y_pred']
        
        # Compute metrics
        acc = accuracy_score(y_true, y_pred)
        
        # Handle edge cases where there might be no positive samples
        prec = precision_score(y_true, y_pred, zero_division=0)
        rec = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        
        # Count positive samples
        num_true_positives = sum(y_true)
        num_pred_positives = sum(y_pred)
        total_samples = len(y_true)
        
        metrics_data.append({
            'Marker_Type': marker_name,
            'Accuracy': acc,
            'Precision': prec,
            'Recall': rec,
            'F1_Score': f1,
            'True_Positives_Count': int(num_true_positives),
            'Predicted_Positives_Count': int(num_pred_positives),
            'Total_Spans': total_samples
        })
    
    # Add macro and micro averages
    all_y_true = []
    all_y_pred = []
    for marker_name in MARKER_TYPES:
        all_y_true.extend(all_predictions[marker_name]['y_true'])
        all_y_pred.extend(all_predictions[marker_name]['y_pred'])
    
    # Macro average (average of per-class metrics)
    macro_acc = sum(m['Accuracy'] for m in metrics_data) / len(MARKER_TYPES)
    macro_prec = sum(m['Precision'] for m in metrics_data) / len(MARKER_TYPES)
    macro_rec = sum(m['Recall'] for m in metrics_data) / len(MARKER_TYPES)
    macro_f1 = sum(m['F1_Score'] for m in metrics_data) / len(MARKER_TYPES)
    
    metrics_data.append({
        'Marker_Type': 'MACRO_AVG',
        'Accuracy': macro_acc,
        'Precision': macro_prec,
        'Recall': macro_rec,
        'F1_Score': macro_f1,
        'True_Positives_Count': '-',
        'Predicted_Positives_Count': '-',
        'Total_Spans': '-'
    })
    
    # Micro average (computed on all predictions together)
    micro_acc = accuracy_score(all_y_true, all_y_pred)
    micro_prec = precision_score(all_y_true, all_y_pred, zero_division=0)
    micro_rec = recall_score(all_y_true, all_y_pred, zero_division=0)
    micro_f1 = f1_score(all_y_true, all_y_pred, zero_division=0)
    
    metrics_data.append({
        'Marker_Type': 'MICRO_AVG',
        'Accuracy': micro_acc,
        'Precision': micro_prec,
        'Recall': micro_rec,
        'F1_Score': micro_f1,
        'True_Positives_Count': int(sum(all_y_true)),
        'Predicted_Positives_Count': int(sum(all_y_pred)),
        'Total_Spans': len(all_y_true)
    })
    
    return pd.DataFrame(metrics_data)


def compute_confusion_matrices(all_predictions: Dict) -> pd.DataFrame:
    """
    Compute confusion matrix for each marker type.
    
    Args:
        all_predictions: Dict from evaluate_model()
        
    Returns:
        DataFrame with confusion matrix values for each marker type
    """
    cm_data = []
    
    for marker_name in MARKER_TYPES:
        y_true = all_predictions[marker_name]['y_true']
        y_pred = all_predictions[marker_name]['y_pred']
        
        # Compute confusion matrix: [[TN, FP], [FN, TP]]
        cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
        
        tn, fp, fn, tp = cm.ravel()
        
        cm_data.append({
            'Marker_Type': marker_name,
            'True_Negative': int(tn),
            'False_Positive': int(fp),
            'False_Negative': int(fn),
            'True_Positive': int(tp),
            'Total': int(tn + fp + fn + tp)
        })
    
    return pd.DataFrame(cm_data)


def create_validation_predictions_jsonl(
    sample_predictions: List[Dict],
    tokenizer,
    output_path: str
):
    """
    Create JSONL file with validation predictions in a format similar to the input data.
    
    Each line contains:
    - _id: Sample ID
    - text: Original text
    - true_markers: List of marker annotations from ground truth
    - predicted_markers: List of marker annotations from model predictions
    
    Args:
        sample_predictions: List from evaluate_model()
        tokenizer: The tokenizer used (to convert tokens back to text)
        output_path: Path to save the JSONL file
    """
    with open(output_path, 'w') as f:
        for sample in sample_predictions:
            sample_id = sample['_id']
            text = sample['text']
            spans = sample['spans']
            labels = sample['labels']        # [num_spans, 5]
            predictions = sample['predictions']  # [num_spans, 5]
            probabilities = sample['probabilities']  # [num_spans, 5]
            input_ids = sample['input_ids']
            
            # Get offset mapping by re-tokenizing (needed for char positions)
            encoding = tokenizer(
                text,
                max_length=128,
                truncation=True,
                padding='max_length',
                return_offsets_mapping=True
            )
            offset_mapping = encoding['offset_mapping']
            
            # Extract true markers from labels
            true_markers = []
            for span_idx, (span_start, span_end) in enumerate(spans):
                for marker_idx, marker_name in enumerate(MARKER_TYPES):
                    if labels[span_idx, marker_idx] > 0.5:
                        # Convert token span to character span
                        char_start, char_end, span_text = token_span_to_char_span(
                            span_start, span_end, offset_mapping, text
                        )
                        if char_start is not None:
                            true_markers.append({
                                'startIndex': char_start,
                                'endIndex': char_end,
                                'type': marker_name,
                                'text': span_text
                            })
            
            # Extract predicted markers from predictions
            predicted_markers = []
            for span_idx, (span_start, span_end) in enumerate(spans):
                for marker_idx, marker_name in enumerate(MARKER_TYPES):
                    if predictions[span_idx, marker_idx] > 0.5:
                        # Convert token span to character span
                        char_start, char_end, span_text = token_span_to_char_span(
                            span_start, span_end, offset_mapping, text
                        )
                        prob = float(probabilities[span_idx, marker_idx])
                        if char_start is not None:
                            predicted_markers.append({
                                'startIndex': char_start,
                                'endIndex': char_end,
                                'type': marker_name,
                                'text': span_text,
                                'confidence': round(prob, 4)
                            })
            
            # Remove duplicate markers (same span and type)
            true_markers = deduplicate_markers(true_markers)
            predicted_markers = deduplicate_markers(predicted_markers)
            
            # Create output record
            output_record = {
                '_id': sample_id,
                'text': text,
                'true_markers': true_markers,
                'predicted_markers': predicted_markers,
                'num_true_markers': len(true_markers),
                'num_predicted_markers': len(predicted_markers)
            }
            
            f.write(json.dumps(output_record) + '\n')


def token_span_to_char_span(
    span_start: int,
    span_end: int,
    offset_mapping: List[Tuple[int, int]],
    text: str
) -> Tuple[Optional[int], Optional[int], Optional[str]]:
    """
    Convert token-level span indices to character-level indices.
    
    Args:
        span_start: Start token index
        span_end: End token index (inclusive)
        offset_mapping: List of (char_start, char_end) for each token
        text: Original text
        
    Returns:
        (char_start, char_end, span_text) or (None, None, None) if invalid
    """
    # Validate indices
    if span_start >= len(offset_mapping) or span_end >= len(offset_mapping):
        return None, None, None
    
    start_offset = offset_mapping[span_start]
    end_offset = offset_mapping[span_end]
    
    # Skip special tokens (offset is (0, 0) for [CLS], [SEP], [PAD])
    if start_offset is None or end_offset is None:
        return None, None, None
    if start_offset == (0, 0) or end_offset == (0, 0):
        # Check if it's actually position 0 in text or a special token
        if span_start == 0 and start_offset == (0, 0):
            # Could be [CLS] token, try to find first real token
            return None, None, None
    
    char_start = start_offset[0]
    char_end = end_offset[1]
    
    # Extract text
    if char_start < len(text) and char_end <= len(text):
        span_text = text[char_start:char_end]
        return char_start, char_end, span_text
    
    return None, None, None


def deduplicate_markers(markers: List[Dict]) -> List[Dict]:
    """
    Remove duplicate markers (same startIndex, endIndex, and type).
    Keep the one with highest confidence if available.
    """
    seen = {}
    for marker in markers:
        key = (marker['startIndex'], marker['endIndex'], marker['type'])
        if key not in seen:
            seen[key] = marker
        elif 'confidence' in marker and 'confidence' in seen[key]:
            if marker['confidence'] > seen[key]['confidence']:
                seen[key] = marker
    return list(seen.values())


def save_metrics_to_csv(
    metrics_df: pd.DataFrame,
    output_path: str
):
    """Save metrics DataFrame to CSV."""
    metrics_df.to_csv(output_path, index=False)
    print(f"✓ Saved metrics to: {output_path}")


def save_confusion_matrices_to_csv(
    cm_df: pd.DataFrame,
    output_path: str
):
    """Save confusion matrices DataFrame to CSV."""
    cm_df.to_csv(output_path, index=False)
    print(f"✓ Saved confusion matrices to: {output_path}")


def run_full_evaluation(
    model,
    val_dataloader,
    device,
    tokenizer,
    output_dir: str,
    threshold: float = 0.5
):
    """
    Run complete evaluation and save all outputs.
    
    Args:
        model: Trained SpanBERTForMarkerExtraction model
        val_dataloader: Validation DataLoader
        device: torch device
        tokenizer: Tokenizer for converting tokens to text
        output_dir: Directory to save output files
        threshold: Threshold for binary predictions (default 0.5)
    
    Saves:
        - {output_dir}/metrics_per_marker.csv
        - {output_dir}/confusion_matrices.csv
        - {output_dir}/validation_predictions.jsonl
    """
    from pathlib import Path
    
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)
    
    print("\n" + "="*70)
    print("RUNNING EVALUATION")
    print("="*70 + "\n")
    
    # Step 1: Get all predictions
    print("Step 1/4: Running inference on validation set...")
    all_predictions, sample_predictions = evaluate_model(
        model, val_dataloader, device, threshold
    )
    
    # Step 2: Compute metrics per marker type
    print("\nStep 2/4: Computing metrics per marker type...")
    metrics_df = compute_metrics_per_marker(all_predictions)
    metrics_path = output_dir / "metrics_per_marker.csv"
    save_metrics_to_csv(metrics_df, metrics_path)
    
    # Print metrics summary
    print("\n--- Metrics Summary ---")
    print(metrics_df.to_string(index=False))
    
    # Step 3: Compute confusion matrices
    print("\nStep 3/4: Computing confusion matrices...")
    cm_df = compute_confusion_matrices(all_predictions)
    cm_path = output_dir / "confusion_matrices.csv"
    save_confusion_matrices_to_csv(cm_df, cm_path)
    
    # Print confusion matrix summary
    print("\n--- Confusion Matrix Summary ---")
    print(cm_df.to_string(index=False))
    
    # Step 4: Save validation predictions
    print("\nStep 4/4: Saving validation predictions...")
    predictions_path = output_dir / "validation_predictions.jsonl"
    create_validation_predictions_jsonl(
        sample_predictions, tokenizer, predictions_path
    )
    print(f"✓ Saved validation predictions to: {predictions_path}")
    
    print("\n" + "="*70)
    print("EVALUATION COMPLETE")
    print("="*70)
    print(f"\nAll outputs saved to: {output_dir}")
    print(f"  - metrics_per_marker.csv")
    print(f"  - confusion_matrices.csv")
    print(f"  - validation_predictions.jsonl")
    
    return metrics_df, cm_df


# Example usage in notebook:
"""
# After training, add this cell:

from evaluation_utils import run_full_evaluation
from transformers import AutoTokenizer

# Load tokenizer
tokenizer = AutoTokenizer.from_pretrained('SpanBERT/spanbert-base-cased')

# Run evaluation (uses the already loaded model and val_loader)
metrics_df, cm_df = run_full_evaluation(
    model=model,
    val_dataloader=val_loader,
    device=device,
    tokenizer=tokenizer,
    output_dir='./spanbert_output',
    threshold=0.5
)
"""
