# =============================================================================
# EVALUATION CELL - Add this after your training cell in the notebook
# =============================================================================
# This cell runs evaluation on the validation set and saves:
# 1. metrics_per_marker.csv - Accuracy, Precision, Recall, F1 for each marker type
# 2. confusion_matrices.csv - TN, FP, FN, TP for each marker type  
# 3. validation_predictions.jsonl - Detailed predictions for each validation sample

import torch
import pandas as pd
import json
from typing import List, Dict, Tuple, Optional
from tqdm import tqdm
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from pathlib import Path
from transformers import AutoTokenizer

# Marker types in order (must match SimpleSpanDataset)
MARKER_TYPES = ["Actor", "Action", "Effect", "Evidence", "Victim"]
MARKER_TO_IDX = {m: i for i, m in enumerate(MARKER_TYPES)}


def evaluate_model(model, dataloader, device, threshold=0.5):
    """
    Run evaluation on the validation set and collect all predictions.
    """
    model.eval()
    
    # Storage for per-marker-type metrics
    all_predictions = {marker: {'y_true': [], 'y_pred': []} for marker in MARKER_TYPES}
    
    # Storage for per-sample detailed predictions
    sample_predictions = []
    
    with torch.no_grad():
        pbar = tqdm(dataloader, desc="Evaluating")
        
        for batch in pbar:
            for sample in batch:
                input_ids = sample['input_ids'].unsqueeze(0).to(device)
                attention_mask = sample['attention_mask'].unsqueeze(0).to(device)
                labels = sample['labels'].unsqueeze(0).to(device)
                spans = sample['spans']
                sample_id = sample['_id']
                text = sample['text']
                
                # Forward pass
                outputs = model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    spans=spans,
                    labels=labels
                )
                
                logits = outputs['logits']
                probs = torch.sigmoid(logits)
                preds = (probs > threshold).float()
                
                labels_np = labels.squeeze(0).cpu().numpy()
                preds_np = preds.squeeze(0).cpu().numpy()
                probs_np = probs.squeeze(0).cpu().numpy()
                
                # Collect predictions for each marker type
                for marker_idx, marker_name in enumerate(MARKER_TYPES):
                    all_predictions[marker_name]['y_true'].extend(labels_np[:, marker_idx].tolist())
                    all_predictions[marker_name]['y_pred'].extend(preds_np[:, marker_idx].tolist())
                
                # Collect per-sample predictions
                sample_predictions.append({
                    '_id': sample_id,
                    'text': text,
                    'spans': spans,
                    'labels': labels_np,
                    'predictions': preds_np,
                    'probabilities': probs_np,
                    'input_ids': sample['input_ids'].numpy()
                })
    
    return all_predictions, sample_predictions


def compute_metrics_per_marker(all_predictions):
    """Compute accuracy, precision, recall, F1 for each marker type."""
    metrics_data = []
    
    for marker_name in MARKER_TYPES:
        y_true = all_predictions[marker_name]['y_true']
        y_pred = all_predictions[marker_name]['y_pred']
        
        acc = accuracy_score(y_true, y_pred)
        prec = precision_score(y_true, y_pred, zero_division=0)
        rec = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        
        metrics_data.append({
            'Marker_Type': marker_name,
            'Accuracy': round(acc, 4),
            'Precision': round(prec, 4),
            'Recall': round(rec, 4),
            'F1_Score': round(f1, 4),
            'True_Positives_Count': int(sum(y_true)),
            'Predicted_Positives_Count': int(sum(y_pred)),
            'Total_Spans': len(y_true)
        })
    
    # Macro average
    macro_metrics = {
        'Marker_Type': 'MACRO_AVG',
        'Accuracy': round(sum(m['Accuracy'] for m in metrics_data) / len(MARKER_TYPES), 4),
        'Precision': round(sum(m['Precision'] for m in metrics_data) / len(MARKER_TYPES), 4),
        'Recall': round(sum(m['Recall'] for m in metrics_data) / len(MARKER_TYPES), 4),
        'F1_Score': round(sum(m['F1_Score'] for m in metrics_data) / len(MARKER_TYPES), 4),
        'True_Positives_Count': '-',
        'Predicted_Positives_Count': '-',
        'Total_Spans': '-'
    }
    metrics_data.append(macro_metrics)
    
    # Micro average
    all_y_true = []
    all_y_pred = []
    for marker_name in MARKER_TYPES:
        all_y_true.extend(all_predictions[marker_name]['y_true'])
        all_y_pred.extend(all_predictions[marker_name]['y_pred'])
    
    metrics_data.append({
        'Marker_Type': 'MICRO_AVG',
        'Accuracy': round(accuracy_score(all_y_true, all_y_pred), 4),
        'Precision': round(precision_score(all_y_true, all_y_pred, zero_division=0), 4),
        'Recall': round(recall_score(all_y_true, all_y_pred, zero_division=0), 4),
        'F1_Score': round(f1_score(all_y_true, all_y_pred, zero_division=0), 4),
        'True_Positives_Count': int(sum(all_y_true)),
        'Predicted_Positives_Count': int(sum(all_y_pred)),
        'Total_Spans': len(all_y_true)
    })
    
    return pd.DataFrame(metrics_data)


def compute_confusion_matrices(all_predictions):
    """Compute confusion matrix for each marker type."""
    cm_data = []
    
    for marker_name in MARKER_TYPES:
        y_true = all_predictions[marker_name]['y_true']
        y_pred = all_predictions[marker_name]['y_pred']
        
        cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
        tn, fp, fn, tp = cm.ravel()
        
        cm_data.append({
            'Marker_Type': marker_name,
            'True_Negative': int(tn),
            'False_Positive': int(fp),
            'False_Negative': int(fn),
            'True_Positive': int(tp),
            'Total': int(tn + fp + fn + tp)
        })
    
    return pd.DataFrame(cm_data)


def token_span_to_char_span(span_start, span_end, offset_mapping, text):
    """Convert token-level span indices to character-level indices."""
    if span_start >= len(offset_mapping) or span_end >= len(offset_mapping):
        return None, None, None
    
    start_offset = offset_mapping[span_start]
    end_offset = offset_mapping[span_end]
    
    if start_offset is None or end_offset is None:
        return None, None, None
    if start_offset == (0, 0) and span_start != 0:
        return None, None, None
    if end_offset == (0, 0) and span_end != 0:
        return None, None, None
    
    char_start = start_offset[0]
    char_end = end_offset[1]
    
    if char_start < len(text) and char_end <= len(text):
        span_text = text[char_start:char_end]
        return char_start, char_end, span_text
    
    return None, None, None


def deduplicate_markers(markers):
    """Remove duplicate markers, keeping highest confidence."""
    seen = {}
    for marker in markers:
        key = (marker['startIndex'], marker['endIndex'], marker['type'])
        if key not in seen:
            seen[key] = marker
        elif 'confidence' in marker and 'confidence' in seen[key]:
            if marker['confidence'] > seen[key]['confidence']:
                seen[key] = marker
    return list(seen.values())


def create_validation_predictions_jsonl(sample_predictions, tokenizer, output_path):
    """Create JSONL file with validation predictions."""
    with open(output_path, 'w') as f:
        for sample in tqdm(sample_predictions, desc="Writing predictions"):
            text = sample['text']
            spans = sample['spans']
            labels = sample['labels']
            predictions = sample['predictions']
            probabilities = sample['probabilities']
            
            # Get offset mapping
            encoding = tokenizer(
                text,
                max_length=128,
                truncation=True,
                padding='max_length',
                return_offsets_mapping=True
            )
            offset_mapping = encoding['offset_mapping']
            
            # Extract true markers
            true_markers = []
            for span_idx, (span_start, span_end) in enumerate(spans):
                for marker_idx, marker_name in enumerate(MARKER_TYPES):
                    if labels[span_idx, marker_idx] > 0.5:
                        char_start, char_end, span_text = token_span_to_char_span(
                            span_start, span_end, offset_mapping, text
                        )
                        if char_start is not None:
                            true_markers.append({
                                'startIndex': char_start,
                                'endIndex': char_end,
                                'type': marker_name,
                                'text': span_text
                            })
            
            # Extract predicted markers
            predicted_markers = []
            for span_idx, (span_start, span_end) in enumerate(spans):
                for marker_idx, marker_name in enumerate(MARKER_TYPES):
                    if predictions[span_idx, marker_idx] > 0.5:
                        char_start, char_end, span_text = token_span_to_char_span(
                            span_start, span_end, offset_mapping, text
                        )
                        prob = float(probabilities[span_idx, marker_idx])
                        if char_start is not None:
                            predicted_markers.append({
                                'startIndex': char_start,
                                'endIndex': char_end,
                                'type': marker_name,
                                'text': span_text,
                                'confidence': round(prob, 4)
                            })
            
            # Deduplicate
            true_markers = deduplicate_markers(true_markers)
            predicted_markers = deduplicate_markers(predicted_markers)
            
            output_record = {
                '_id': sample['_id'],
                'text': text,
                'true_markers': true_markers,
                'predicted_markers': predicted_markers,
                'num_true_markers': len(true_markers),
                'num_predicted_markers': len(predicted_markers)
            }
            
            f.write(json.dumps(output_record) + '\n')


def run_full_evaluation(model, val_dataloader, device, tokenizer, output_dir, threshold=0.5):
    """
    Run complete evaluation and save all outputs.
    
    Saves:
        - metrics_per_marker.csv
        - confusion_matrices.csv  
        - validation_predictions.jsonl
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)
    
    print("\n" + "="*70)
    print("RUNNING EVALUATION")
    print("="*70 + "\n")
    
    # Step 1: Get all predictions
    print("Step 1/4: Running inference on validation set...")
    all_predictions, sample_predictions = evaluate_model(
        model, val_dataloader, device, threshold
    )
    
    # Step 2: Compute metrics per marker type
    print("\nStep 2/4: Computing metrics per marker type...")
    metrics_df = compute_metrics_per_marker(all_predictions)
    metrics_path = output_dir / "metrics_per_marker.csv"
    metrics_df.to_csv(metrics_path, index=False)
    print(f"✓ Saved metrics to: {metrics_path}")
    
    print("\n--- Metrics Summary ---")
    print(metrics_df.to_string(index=False))
    
    # Step 3: Compute confusion matrices
    print("\nStep 3/4: Computing confusion matrices...")
    cm_df = compute_confusion_matrices(all_predictions)
    cm_path = output_dir / "confusion_matrices.csv"
    cm_df.to_csv(cm_path, index=False)
    print(f"✓ Saved confusion matrices to: {cm_path}")
    
    print("\n--- Confusion Matrix Summary ---")
    print(cm_df.to_string(index=False))
    
    # Step 4: Save validation predictions
    print("\nStep 4/4: Saving validation predictions...")
    predictions_path = output_dir / "validation_predictions.jsonl"
    create_validation_predictions_jsonl(sample_predictions, tokenizer, predictions_path)
    print(f"✓ Saved validation predictions to: {predictions_path}")
    
    print("\n" + "="*70)
    print("EVALUATION COMPLETE")
    print("="*70)
    print(f"\nAll outputs saved to: {output_dir}")
    
    return metrics_df, cm_df


# =============================================================================
# RUN EVALUATION
# =============================================================================
# Make sure this runs AFTER your training cell has completed

# Load the tokenizer (same one used for training)
eval_tokenizer = AutoTokenizer.from_pretrained(args.model_name)

# Run full evaluation using the trained model and validation loader
# 'model' and 'val_loader' should already be defined from your training cell
# 'device' should also be defined from training

metrics_df, cm_df = run_full_evaluation(
    model=model,
    val_dataloader=val_loader,
    device=device,
    tokenizer=eval_tokenizer,
    output_dir=args.output_dir,
    threshold=0.5  # You can adjust this threshold
)

print("\n✓ Evaluation complete! Check your output directory for:")
print("  - metrics_per_marker.csv")
print("  - confusion_matrices.csv")
print("  - validation_predictions.jsonl")
