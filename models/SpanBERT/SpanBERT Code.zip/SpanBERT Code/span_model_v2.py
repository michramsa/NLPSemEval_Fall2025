import torch
import torch.nn as nn
from transformers import AutoModel, AutoConfig
from typing import Optional, Tuple, List


class SpanBERTForMarkerExtraction(nn.Module):
    def __init__(
        self,
        pretrained_model_name: str = "SpanBERT/spanbert-base-cased",
        max_span_length: int = 20,
        num_labels: int = 5,  # Actor, Action, Effect, Evidence, Victim
        dropout: float = 0.1,
        width_embedding_dim: int = 20,
        pos_weight: Optional[torch.Tensor] = None  # NEW: weight for positive class
    ):
        super().__init__()
        
        self.max_span_length = max_span_length
        self.num_labels = num_labels
        
        # Store pos_weight for loss calculation
        # If not provided, will be set later or default to None (unweighted)
        self.register_buffer('pos_weight', pos_weight)
        
        print(f"Loading SpanBERT from {pretrained_model_name}...")
        self.bert = AutoModel.from_pretrained(pretrained_model_name)
        self.config = self.bert.config
        # to clarify - it's sourcing this number from https://huggingface.co/SpanBERT/spanbert-base-cased/blob/main/config.json
        self.hidden_size = self.config.hidden_size  # 768 for base model 
        
        # Width embeddings: learned representations for span lengths 1 to max_span_length
        # Why? Different marker types have different typical lengths:
        # - Victim: avg 1.57 tokens
        # - Actor: avg 2.25 tokens  
        # - Effect: avg 5.62 tokens
        # The model learns to associate span width with marker types
        self.width_embedding = nn.Embedding(
            num_embeddings=max_span_length,  # Lengths from 1 to max_span_length
            embedding_dim=width_embedding_dim
        )
        
        # Span representation size calculation:
        # - Start hidden state: hidden_size (768)
        # - End hidden state: hidden_size (768)
        # - Element-wise product: hidden_size (768)
        # - Width embedding: width_embedding_dim (20)
        # Total: 768 + 768 + 768 + 20 = 2324
        span_repr_size = 3 * self.hidden_size + width_embedding_dim
        
        # Classification head: maps span representation to 5 binary predictions
        # Each prediction is independent (multi-label, not multi-class)
        self.classifier = nn.Sequential(
            nn.Linear(span_repr_size, span_repr_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(span_repr_size // 2, num_labels)
        )
        
        print(f"✓ Model initialized")
        print(f"  - Hidden size: {self.hidden_size}")
        print(f"  - Max span length: {max_span_length}")
        print(f"  - Span representation size: {span_repr_size}")
        print(f"  - Number of labels: {num_labels}")
        if pos_weight is not None:
            print(f"  - Positive class weights: {pos_weight.tolist()}")
    
    def set_pos_weight(self, pos_weight: torch.Tensor):
        """
        Set positive class weights after initialization.
        Useful when computing weights from training data.
        
        Args:
            pos_weight: Tensor of shape [num_labels] with weight for each marker type
        """
        self.register_buffer('pos_weight', pos_weight)
        print(f"✓ Updated positive class weights: {pos_weight.tolist()}")
    
    def enumerate_spans(
        self, 
        sequence_length: int,
        max_span_length: Optional[int] = None
    ) -> List[Tuple[int, int]]:
        """
        Enumerate all valid spans in a sequence.
        
        Example for sequence_length=5, max_span_length=3:
            Returns: [(0,0), (0,1), (0,2), (1,1), (1,2), (1,3), (2,2), (2,3), (2,4), (3,3), (3,4), (4,4)]
            These represent spans: [0], [0-1], [0-2], [1], [1-2], [1-3], etc.
        
        Args:
            sequence_length: Number of tokens in sequence
            max_span_length: Maximum span width (default: self.max_span_length)
            
        Returns:
            List of (start_idx, end_idx) tuples (end_idx is inclusive)
        """
        if max_span_length is None:
            max_span_length = self.max_span_length
            
        spans = []
        for start_idx in range(sequence_length):
            for end_idx in range(start_idx, min(start_idx + max_span_length, sequence_length)):
                spans.append((start_idx, end_idx))
        
        return spans
    
    def get_span_representations(
        self,
        sequence_output: torch.Tensor,  # [batch_size, seq_len, hidden_size]
        spans: List[Tuple[int, int]]     # List of (start, end) tuples
    ) -> torch.Tensor:
        """
        Create span representations using the SpanBERT methodology.
        
        For each span [i, j], representation is:
            [h_i; h_j; h_i ⊙ h_j; φ(j-i+1)]
        
        Where:
            h_i = hidden state at start position
            h_j = hidden state at end position
            ⊙ = element-wise multiplication
            φ(width) = learned width embedding
        
        Args:
            sequence_output: BERT hidden states [batch_size, seq_len, hidden_size]
            spans: List of (start_idx, end_idx) tuples
            
        Returns:
            Span representations [batch_size, num_spans, span_repr_size]
        """
        batch_size = sequence_output.size(0)
        num_spans = len(spans)
        
        # Extract start and end indices
        span_starts = torch.tensor([s[0] for s in spans], device=sequence_output.device)  # [num_spans]
        span_ends = torch.tensor([s[1] for s in spans], device=sequence_output.device)    # [num_spans]
        
        # Get hidden states at start and end positions
        # We need to expand for batch dimension
        span_starts_expanded = span_starts.unsqueeze(0).expand(batch_size, -1)  # [batch_size, num_spans]
        span_ends_expanded = span_ends.unsqueeze(0).expand(batch_size, -1)      # [batch_size, num_spans]
        
        # Gather hidden states
        # sequence_output: [batch_size, seq_len, hidden_size]
        # We want to select specific positions for each span
        
        # Expand indices for gathering: [batch_size, num_spans, hidden_size]
        span_starts_idx = span_starts_expanded.unsqueeze(-1).expand(-1, -1, self.hidden_size)
        span_ends_idx = span_ends_expanded.unsqueeze(-1).expand(-1, -1, self.hidden_size)
        
        # Gather start and end hidden states
        start_hidden = torch.gather(sequence_output, 1, span_starts_idx)  # [batch_size, num_spans, hidden_size]
        end_hidden = torch.gather(sequence_output, 1, span_ends_idx)      # [batch_size, num_spans, hidden_size]
        
        # Element-wise product (captures interaction between start and end)
        product_hidden = start_hidden * end_hidden  # [batch_size, num_spans, hidden_size]
        
        # Width embeddings: span width = end - start + 1 (e.g., span [2,2] has width 1)
        span_widths = span_ends - span_starts  # [num_spans], values from 0 to max_span_length-1
        width_embeds = self.width_embedding(span_widths)  # [num_spans, width_embedding_dim]
        width_embeds = width_embeds.unsqueeze(0).expand(batch_size, -1, -1)  # [batch_size, num_spans, width_embedding_dim]
        
        # Concatenate all components
        span_repr = torch.cat([
            start_hidden,    # [batch_size, num_spans, hidden_size]
            end_hidden,      # [batch_size, num_spans, hidden_size]
            product_hidden,  # [batch_size, num_spans, hidden_size]
            width_embeds     # [batch_size, num_spans, width_embedding_dim]
        ], dim=-1)  # [batch_size, num_spans, 3*hidden_size + width_embedding_dim]
        
        return span_repr
    
    def forward(
        self,
        input_ids: torch.Tensor,           # [batch_size, seq_len]
        attention_mask: torch.Tensor,      # [batch_size, seq_len]
        spans: Optional[List[Tuple[int, int]]] = None,  # If None, enumerate all spans
        labels: Optional[torch.Tensor] = None  # [batch_size, num_spans, num_labels] for training
    ) -> dict:
        """
        Forward pass through the model.
        
        Args:
            input_ids: Token IDs from tokenizer
            attention_mask: Attention mask (1 for real tokens, 0 for padding)
            spans: Optional list of (start, end) tuples. If None, enumerates all spans
            labels: Optional ground truth labels for training [batch_size, num_spans, num_labels]
        
        Returns:
            Dictionary containing:
                - logits: [batch_size, num_spans, num_labels]
                - loss: scalar (if labels provided)
                - spans: list of (start, end) tuples
        """
        # Get BERT contextual embeddings
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask
        )
        sequence_output = outputs.last_hidden_state  # [batch_size, seq_len, hidden_size]
        
        # Enumerate spans if not provided
        if spans is None:
            # Get sequence length (excluding padding)
            seq_len = int(attention_mask.sum(dim=1).max().item())
            spans = self.enumerate_spans(seq_len)
        
        # Get span representations
        span_repr = self.get_span_representations(sequence_output, spans)
        # [batch_size, num_spans, span_repr_size]
        
        # Classify each span for all 5 marker types
        logits = self.classifier(span_repr)  # [batch_size, num_spans, num_labels]
        
        result = {
            'logits': logits,
            'spans': spans
        }
        
        # Compute loss if labels are provided (training mode)
        if labels is not None:
            # Multi-label classification: each marker type is independent
            # Use Binary Cross Entropy with Logits, with optional positive class weighting
            loss_fct = nn.BCEWithLogitsLoss(pos_weight=self.pos_weight)
            loss = loss_fct(logits, labels.float())
            result['loss'] = loss
        
        return result


def compute_pos_weights(dataset, num_labels: int = 5) -> torch.Tensor:
    """
    Compute positive class weights from dataset statistics.
    
    Weight = num_negative / num_positive for each marker type
    
    This makes the loss treat each positive example as if it were
    worth `weight` negative examples, balancing the contribution.
    
    Args:
        dataset: SimpleSpanDataset instance
        num_labels: Number of marker types (default 5)
        
    Returns:
        Tensor of shape [num_labels] with weight for each marker type
    """
    print("Computing positive class weights from training data...")
    
    # Count positives and total for each marker type
    pos_counts = torch.zeros(num_labels)
    total_counts = torch.zeros(num_labels)
    
    for idx in range(len(dataset)):
        sample = dataset[idx]
        labels = sample['labels']  # [num_spans, num_labels]
        
        for label_idx in range(num_labels):
            pos_counts[label_idx] += labels[:, label_idx].sum().item()
            total_counts[label_idx] += labels.shape[0]
    
    # Compute weights: neg_count / pos_count
    neg_counts = total_counts - pos_counts
    
    # Avoid division by zero
    pos_counts = torch.clamp(pos_counts, min=1.0)
    
    weights = neg_counts / pos_counts
    
    # Print statistics
    marker_types = ["Actor", "Action", "Effect", "Evidence", "Victim"]
    print("\nClass distribution:")
    print("-" * 60)
    for i, marker in enumerate(marker_types):
        pos_rate = pos_counts[i] / total_counts[i] * 100
        print(f"  {marker:10s}: {int(pos_counts[i]):>8} pos / {int(total_counts[i]):>10} total ({pos_rate:.2f}%) -> weight: {weights[i]:.1f}")
    print("-" * 60)
    
    return weights


# Test the model
if __name__ == "__main__":
    print("\n" + "="*60)
    print("Testing SpanBERT Model with Weighted BCE")
    print("="*60 + "\n")
    
    # Example weights (you would compute these from your data)
    example_weights = torch.tensor([50.0, 50.0, 60.0, 70.0, 100.0])
    
    # Initialize model with weights
    model = SpanBERTForMarkerExtraction(
        max_span_length=20,
        num_labels=5,
        pos_weight=example_weights
    )
    
    # Create dummy input
    batch_size = 2
    seq_len = 10
    
    input_ids = torch.randint(0, 28996, (batch_size, seq_len))  # SpanBERT vocab size
    attention_mask = torch.ones(batch_size, seq_len)
    
    print(f"\nInput shapes:")
    print(f"  input_ids: {input_ids.shape}")
    print(f"  attention_mask: {attention_mask.shape}")
    
    # Forward pass without labels
    with torch.no_grad():
        outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    
    print(f"\nOutput shapes:")
    print(f"  logits: {outputs['logits'].shape}")
    print(f"  number of spans: {len(outputs['spans'])}")
    
    # Forward pass with labels (to test weighted loss)
    num_spans = len(outputs['spans'])
    dummy_labels = torch.zeros(batch_size, num_spans, 5)
    dummy_labels[0, 0, 0] = 1  # One positive example
    
    with torch.no_grad():
        outputs_with_loss = model(
            input_ids=input_ids, 
            attention_mask=attention_mask,
            spans=outputs['spans'],
            labels=dummy_labels
        )
    
    print(f"  loss (weighted): {outputs_with_loss['loss'].item():.4f}")
    
    print(f"\n✓ Model test passed!")
