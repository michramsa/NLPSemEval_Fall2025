# small data for SpanBERT - FIXED VERSION

import json
import torch
from torch.utils.data import Dataset
from transformers import AutoTokenizer
from typing import List, Dict, Tuple


class SimpleSpanDataset(Dataset):
    """
    Simple dataset for SpanBERT marker extraction.
    
    Converts JSONL format to model inputs.
    """
    
    # Marker types in order
    MARKER_TYPES = ["Actor", "Action", "Effect", "Evidence", "Victim"]
    MARKER_TO_IDX = {m: i for i, m in enumerate(MARKER_TYPES)}
    
    def __init__(
        self,
        jsonl_path: str,
        tokenizer_name: str = "SpanBERT/spanbert-base-cased",
        max_span_length: int = 20,
        max_seq_length: int = 128
    ):
        self.max_span_length = max_span_length
        self.max_seq_length = max_seq_length
        
        # Load tokenizer
        print(f"Loading tokenizer: {tokenizer_name}")
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
        
        # Load data
        print(f"Loading data from: {jsonl_path}")
        self.samples = self._load_data(jsonl_path)
        print(f"Loaded {len(self.samples)} samples\n")
    
    def _load_data(self, jsonl_path: str) -> List[Dict]:
        """Load and tokenize all samples."""
        samples = []
        
        with open(jsonl_path, 'r') as f:
            for i, line in enumerate(f):
                try:
                    data = json.loads(line.strip())
                    
                    # Skip if missing required fields
                    if '_id' not in data or 'text' not in data:
                        continue
                    
                    # Tokenize with offset mapping (character positions)
                    encoding = self.tokenizer(
                        data['text'],
                        max_length=self.max_seq_length,
                        truncation=True,
                        padding='max_length',
                        return_offsets_mapping=True
                    )
                    
                    # Store everything we need
                    sample = {
                        'input_ids': torch.tensor(encoding['input_ids']),
                        'attention_mask': torch.tensor(encoding['attention_mask']),
                        'offset_mapping': encoding['offset_mapping'],
                        'text': data['text'],
                        '_id': data['_id'],
                        'markers': data.get('markers', []),
                        'conspiracy': data.get('conspiracy', 'No')
                    }
                    
                    samples.append(sample)
                    
                except Exception as e:
                    print(f"Error on line {i}: {e}")
        
        return samples
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        """Get a single sample."""
        sample = self.samples[idx]
        
        # Find actual sequence length (non-padded tokens)
        seq_len = int(sample['attention_mask'].sum())
        
        # Enumerate all possible spans
        spans = self._enumerate_spans(seq_len)
        
        ### some random empty list 
        safe_markers = sample.get('markers')
        if safe_markers is None:
            safe_markers = []

        labels = self._create_labels(
            markers=safe_markers,
            offset_mapping=sample['offset_mapping'],
            spans=spans
        )
                
        return {
            'input_ids': sample['input_ids'],
            'attention_mask': sample['attention_mask'],
            'spans': spans,
            'labels': labels,
            '_id': sample['_id'],
            'text': sample['text']
        }
    
    def _enumerate_spans(self, seq_len: int) -> List[Tuple[int, int]]:
        """
        Create all possible spans up to max_span_length.
        
        Example: seq_len=5, max_span=3
        Returns: [(0,0), (0,1), (0,2), (1,1), (1,2), (1,3), (2,2), (2,3), (2,4), (3,3), (3,4), (4,4)]
        """
        spans = []
        for start in range(seq_len):
            for end in range(start, min(start + self.max_span_length, seq_len)):
                spans.append((start, end))
        return spans
    
    def _create_labels(
        self,
        markers: List[Dict],
        offset_mapping: List[Tuple[int, int]],
        spans: List[Tuple[int, int]]
    ) -> torch.Tensor:
        """
        Create binary label matrix [num_spans x 5] for multi-label classification.
        
        For each span, check if it EXACTLY matches any marker annotation.
        Label is 1 only if the span tokens exactly equal the marker tokens.
        
        Args:
            markers: List of marker annotations with startIndex, endIndex, type
            offset_mapping: Token to character mapping from tokenizer
            spans: List of (start_tok, end_tok) tuples
            
        Returns:
            Binary tensor of shape [num_spans, 5]
        """
        num_spans = len(spans)
        labels = torch.zeros(num_spans, 5, dtype=torch.float32)

        # Safe check for markers
        if not markers or not isinstance(markers, list):
            return labels  # Return all zeros if no valid markers

        # For each marker annotation
        for marker in markers:
            marker_type = marker.get('type')
            if marker_type not in self.MARKER_TO_IDX:
                continue
            
            label_idx = self.MARKER_TO_IDX[marker_type]
            char_start = marker['startIndex']
            char_end = marker['endIndex']
            
            # Find which tokens overlap with this character span
            marker_tokens = set()
            for tok_idx, (tok_start, tok_end) in enumerate(offset_mapping):
                # Skip special tokens (offset is None or (0,0))
                if tok_start is None or tok_end is None:
                    continue
                # Skip [CLS], [SEP], [PAD] tokens which have (0,0) offset
                if tok_start == 0 and tok_end == 0 and tok_idx != 0:
                    continue
                # Special case: first token at position 0 might legitimately start at char 0
                if tok_idx == 0 and tok_start == 0 and tok_end == 0:
                    continue
                
                # Check if token overlaps with marker character span
                if char_start < tok_end and char_end > tok_start:
                    marker_tokens.add(tok_idx)
            
            # Skip if no tokens found for this marker (might be truncated)
            if not marker_tokens:
                continue
            
            # Now check which enumerated spans EXACTLY match this marker
            for span_idx, (span_start, span_end) in enumerate(spans):
                # Get tokens in this span (inclusive range)
                span_tokens = set(range(span_start, span_end + 1))
                
                # FIX: Require EXACT match instead of IoU overlap
                if span_tokens == marker_tokens:
                    labels[span_idx, label_idx] = 1.0
      
        return labels


def test_dataset():
    """Test the dataset on a small sample."""
    print("="*60)
    print("Testing SimpleSpanDataset (FIXED)")
    print("="*60 + "\n")
    
    # You'll need to update this path
    dataset = SimpleSpanDataset(
        jsonl_path="train_mini.jsonl",  # Your small test file
        max_span_length=20,
        max_seq_length=128
    )
    
    if len(dataset) == 0:
        print("No samples loaded! Check your file path.")
        return
    
    # Get first sample
    print("Testing first sample...")
    sample = dataset[0]
    
    print(f"\n--- Sample 0 ---")
    print(f"ID: {sample['_id']}")
    print(f"Text: {sample['text'][:100]}...")
    print(f"\nShapes:")
    print(f"  input_ids: {sample['input_ids'].shape}")
    print(f"  attention_mask: {sample['attention_mask'].shape}")
    print(f"  labels: {sample['labels'].shape}")
    print(f"  num_spans: {len(sample['spans'])}")
    
    # Check how many positive labels
    num_positive = (sample['labels'].sum(dim=1) > 0).sum().item()
    print(f"\nLabel Statistics:")
    print(f"  Total spans: {len(sample['spans'])}")
    print(f"  Spans with markers: {num_positive}")
    print(f"  Total positive labels: {sample['labels'].sum().item()}")
    
    # Show some positive examples
    positive_spans = (sample['labels'].sum(dim=1) > 0).nonzero(as_tuple=True)[0]
    if len(positive_spans) > 0:
        print(f"\n--- Positive Span Examples ---")
        for i in positive_spans[:3]:  # Show first 3
            span_start, span_end = sample['spans'][i]
            label_vec = sample['labels'][i]
            
            # Get marker types
            marker_types = [SimpleSpanDataset.MARKER_TYPES[j] 
                          for j in range(5) if label_vec[j] > 0]
            
            print(f"  Span [{span_start}, {span_end}]: {marker_types}")
    
    print(f"\n Dataset test passed!")


if __name__ == "__main__":
    test_dataset()
